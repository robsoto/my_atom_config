(function() {
  exports.Emitter = require('./emitter');

  exports.Disposable = require('./disposable');

  exports.CompositeDisposable = require('./composite-disposable');

}).call(this);
