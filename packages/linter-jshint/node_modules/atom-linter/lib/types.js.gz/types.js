'use strict';
'use babel';
