'use strict';
'use babel';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.assign = exports.unlinkFile = exports.writeFile = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

exports.getTempDirectory = getTempDirectory;
exports.fileExists = fileExists;
exports.validateExec = validateExec;
exports.validateEditor = validateEditor;
exports.validateFind = validateFind;

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _tmp = require('tmp');

var _tmp2 = _interopRequireDefault(_tmp);

var _sbPromisify = require('sb-promisify');

var _sbPromisify2 = _interopRequireDefault(_sbPromisify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var writeFile = exports.writeFile = (0, _sbPromisify2.default)(_fs2.default.writeFile);
var unlinkFile = exports.unlinkFile = (0, _sbPromisify2.default)(_fs2.default.unlink);
var assign = exports.assign = Object.assign || function (target, source) {
  for (var key in source) {
    if (source.hasOwnProperty(key)) {
      target[key] = source[key];
    }
  }
  return target;
};

function getTempDirectory(prefix) {
  return new Promise(function (resolve, reject) {
    _tmp2.default.dir({ prefix: prefix }, function (error, directory, cleanup) {
      if (error) {
        reject(error);
      } else resolve({ path: directory, cleanup: cleanup });
    });
  });
}

function fileExists(filePath) {
  return new Promise(function (resolve) {
    _fs2.default.access(filePath, _fs2.default.R_OK, function (error) {
      resolve(error === null);
    });
  });
}

function validateExec(command, args, options) {
  if (typeof command !== 'string') {
    throw new Error('Invalid or no `command` provided');
  } else if (!(args instanceof Array)) {
    throw new Error('Invalid or no `args` provided');
  } else if ((typeof options === 'undefined' ? 'undefined' : _typeof(options)) !== 'object') {
    throw new Error('Invalid or no `options` provided');
  }
}

function validateEditor(editor) {
  var isEditor = void 0;
  if (typeof atom.workspace.isTextEditor === 'function') {
    // Added in Atom v1.4.0
    isEditor = atom.workspace.isTextEditor(editor);
  } else {
    isEditor = typeof editor.getText === 'function';
  }
  if (!isEditor) {
    throw new Error('Invalid TextEditor provided');
  }
}

function validateFind(directory, name) {
  if (typeof directory !== 'string') {
    throw new Error('Invalid or no `directory` provided');
  } else if (typeof name !== 'string' && !(name instanceof Array)) {
    throw new Error('Invalid or no `name` provided');
  }
}
