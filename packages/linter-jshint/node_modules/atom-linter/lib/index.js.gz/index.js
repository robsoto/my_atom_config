'use strict';
'use babel';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.execNode = exports.exec = exports.tempFiles = exports.findCachedAsync = exports.findAsync = exports.FindCache = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

var findAsync = exports.findAsync = function () {
  var ref = _asyncToGenerator(function* (directory, name) {
    Helpers.validateFind(directory, name);
    var names = [].concat(name);
    var chunks = directory.split(Path.sep);

    while (chunks.length) {
      var currentDir = chunks.join(Path.sep);
      if (currentDir === '') {
        currentDir = Path.resolve(directory, '/');
      }
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = names[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var fileName = _step.value;

          var _filePath = Path.join(currentDir, fileName);
          if (yield Helpers.fileExists(_filePath)) {
            return _filePath;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      chunks.pop();
    }

    return null;
  });

  return function findAsync(_x, _x2) {
    return ref.apply(this, arguments);
  };
}();

var findCachedAsync = exports.findCachedAsync = function () {
  var ref = _asyncToGenerator(function* (directory, name) {
    Helpers.validateFind(directory, name);
    var names = [].concat(name);
    var cacheKey = directory + ':' + names.join(',');
    var cachedFilePath = FindCache.get(cacheKey);

    if (cachedFilePath) {
      if (yield Helpers.fileExists(cachedFilePath)) {
        return cachedFilePath;
      }
      FindCache.delete(cacheKey);
    }
    var filePath = yield findAsync(directory, names);
    if (filePath) {
      FindCache.set(cacheKey, filePath);
    }
    return filePath;
  });

  return function findCachedAsync(_x3, _x4) {
    return ref.apply(this, arguments);
  };
}();

var tempFiles = exports.tempFiles = function () {
  var ref = _asyncToGenerator(function* (files, callback) {
    if (!Array.isArray(files)) {
      throw new Error('Invalid or no `files` provided');
    } else if (typeof callback !== 'function') {
      throw new Error('Invalid or no `callback` provided');
    }

    var tempDirectory = yield Helpers.getTempDirectory('atom-linter_');
    var filePaths = [];
    var result = void 0;
    var error = void 0;

    yield Promise.all(files.map(function (file) {
      var fileName = file.name;
      var fileContents = file.contents;
      var filePath = Path.join(tempDirectory.path, fileName);
      filePaths.push(filePath);
      return Helpers.writeFile(filePath, fileContents);
    }));
    try {
      result = yield callback(filePaths);
    } catch (_) {
      error = _;
    }
    yield Promise.all(filePaths.map(function (filePath) {
      return Helpers.unlinkFile(filePath);
    }));
    tempDirectory.cleanup();
    if (error) {
      throw error;
    }
    return result;
  });

  return function tempFiles(_x5, _x6) {
    return ref.apply(this, arguments);
  };
}();

exports.rangeFromLineNumber = rangeFromLineNumber;
exports.find = find;
exports.findCached = findCached;
exports.tempFile = tempFile;
exports.parse = parse;

var _sbExec = require('sb-exec');

Object.defineProperty(exports, 'exec', {
  enumerable: true,
  get: function get() {
    return _sbExec.exec;
  }
});
Object.defineProperty(exports, 'execNode', {
  enumerable: true,
  get: function get() {
    return _sbExec.execNode;
  }
});

var _path = require('path');

var Path = _interopRequireWildcard(_path);

var _fs = require('fs');

var FS = _interopRequireWildcard(_fs);

var _helpers = require('./helpers');

var Helpers = _interopRequireWildcard(_helpers);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { return step("next", value); }, function (err) { return step("throw", err); }); } } return step("next"); }); }; }

var NamedRegexp = null;
var FindCache = exports.FindCache = new Map();

function rangeFromLineNumber(textEditor, line, column) {
  Helpers.validateEditor(textEditor);
  var lineNumber = line;

  if (!Number.isFinite(lineNumber) || Number.isNaN(lineNumber) || lineNumber < 0) {
    lineNumber = 0;
  }

  var buffer = textEditor.getBuffer();
  var lineMax = buffer.getLineCount() - 1;

  if (lineNumber > lineMax) {
    throw new Error('Line number (' + lineNumber + ') greater than maximum line (' + lineMax + ')');
  }

  var colStart = column;
  if (!Number.isFinite(colStart) || Number.isNaN(colStart) || colStart < 0) {
    var indentation = buffer.lineForRow(lineNumber).match(/^\s+/);
    if (indentation && indentation.length) {
      colStart = indentation[0].length;
    } else {
      colStart = 0;
    }
  }

  var lineLength = buffer.lineLengthForRow(lineNumber);

  if (colStart > lineLength) {
    throw new Error('Column start (' + colStart + ') greater than line length (' + lineLength + ')');
  }

  return [[lineNumber, colStart], [lineNumber, lineLength]];
}

function find(directory, name) {
  Helpers.validateFind(directory, name);
  var names = [].concat(name);
  var chunks = directory.split(Path.sep);

  while (chunks.length) {
    var currentDir = chunks.join(Path.sep);
    if (currentDir === '') {
      currentDir = Path.resolve(directory, '/');
    }
    var _iteratorNormalCompletion2 = true;
    var _didIteratorError2 = false;
    var _iteratorError2 = undefined;

    try {
      for (var _iterator2 = names[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
        var fileName = _step2.value;

        var _filePath2 = Path.join(currentDir, fileName);

        try {
          FS.accessSync(_filePath2, FS.R_OK);
          return _filePath2;
        } catch (_) {
          // Do nothing
        }
      }
    } catch (err) {
      _didIteratorError2 = true;
      _iteratorError2 = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion2 && _iterator2.return) {
          _iterator2.return();
        }
      } finally {
        if (_didIteratorError2) {
          throw _iteratorError2;
        }
      }
    }

    chunks.pop();
  }

  return null;
}

function findCached(directory, name) {
  Helpers.validateFind(directory, name);
  var names = [].concat(name);
  var cacheKey = directory + ':' + names.join(',');
  var cachedFilePath = FindCache.get(cacheKey);

  if (cachedFilePath) {
    try {
      FS.accessSync(cachedFilePath, FS.R_OK);
      return cachedFilePath;
    } catch (_) {
      FindCache.delete(cacheKey);
    }
  }
  var filePath = find(directory, names);
  if (filePath) {
    FindCache.set(cacheKey, filePath);
  }
  return filePath;
}

function tempFile(fileName, fileContents, callback) {
  if (typeof fileName !== 'string') {
    throw new Error('Invalid or no `fileName` provided');
  } else if (typeof fileContents !== 'string') {
    throw new Error('Invalid or no `fileContents` provided');
  } else if (typeof callback !== 'function') {
    throw new Error('Invalid or no `callback` provided');
  }

  return tempFiles([{
    name: fileName,
    contents: fileContents
  }], function (results) {
    return callback(results[0]);
  });
}

function parse(data, regex) {
  var opts = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

  if (typeof data !== 'string') {
    throw new Error('Invalid or no `data` provided');
  } else if (typeof regex !== 'string') {
    throw new Error('Invalid or no `regex` provided');
  } else if ((typeof opts === 'undefined' ? 'undefined' : _typeof(opts)) !== 'object') {
    throw new Error('Invalid or no `options` provided');
  }

  if (NamedRegexp === null) {
    NamedRegexp = require('named-js-regexp');
  }

  var options = Helpers.assign({ flags: '' }, opts);
  if (options.flags.indexOf('g') === -1) {
    options.flags += 'g';
  }

  var messages = [];
  var compiledRegexp = new NamedRegexp(regex, options.flags);
  var rawMatch = compiledRegexp.exec(data);

  while (rawMatch !== null) {
    var match = rawMatch.groups();
    var type = match.type;
    var text = match.message;
    var file = match.file || options.filePath || null;

    var lineStart = match.lineStart || match.line || 0;
    var colStart = match.colStart || match.col || 0;
    var lineEnd = match.lineEnd || match.line || 0;
    var colEnd = match.colEnd || match.col || 0;

    messages.push({
      type: type,
      text: text,
      filePath: file,
      range: [[lineStart > 0 ? lineStart - 1 : 0, colStart > 0 ? colStart - 1 : 0], [lineEnd > 0 ? lineEnd - 1 : 0, colEnd > 0 ? colEnd - 1 : 0]]
    });

    rawMatch = compiledRegexp.exec(data);
  }

  return messages;
}
