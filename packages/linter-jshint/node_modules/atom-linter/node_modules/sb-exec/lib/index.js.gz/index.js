'use strict';

var exec = function () {
  var ref = _asyncToGenerator(function* (filePath) {
    var parameters = arguments.length <= 1 || arguments[1] === undefined ? [] : arguments[1];
    var options = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

    (0, _helpers.validate)(filePath, parameters, options);
    var spawnOptions = yield (0, _helpers.getSpawnOptions)(options);
    if (process.platform === 'win32') {
      filePath = yield (0, _extify2.default)(filePath, (0, _helpers.mergeAllPaths)(spawnOptions.env), (0, _helpers.mergeAllPathExts)(spawnOptions.env));
    }

    return yield new Promise(function (resolve, reject) {
      var spawnedProcess = (0, _child_process.spawn)(filePath, parameters, spawnOptions);
      var data = { stdout: [], stderr: [] };
      var timeout = void 0;

      if (spawnedProcess.stdout) {
        spawnedProcess.stdout.on('data', function (chunk) {
          data.stdout.push(chunk);
        });
      }
      if (spawnedProcess.stderr) {
        spawnedProcess.stderr.on('data', function (chunk) {
          data.stderr.push(chunk);
        });
      }
      spawnedProcess.on('error', function (error) {
        reject(error);
      });
      spawnedProcess.on('close', function () {
        clearTimeout(timeout);
        if (options.stream === 'stdout') {
          if (data.stderr.length && options.throwOnStdErr) {
            reject(new Error(data.stderr.join('').trim()));
          } else {
            resolve(data.stdout.join('').trim());
          }
        } else if (options.stream === 'stderr') {
          resolve(data.stderr.join('').trim());
        } else {
          resolve({ stdout: data.stdout.join('').trim(), stderr: data.stderr.join('').trim() });
        }
      });

      if (spawnedProcess.stdin) {
        if (options.stdin) {
          try {
            spawnedProcess.stdin.write(options.stdin);
          } catch (_) {/* No Op */}
        }
        try {
          spawnedProcess.stdin.end();
        } catch (_) {/* No Op */}
      }

      if (options.timeout !== Infinity) {
        timeout = setTimeout(function () {
          try {
            spawnedProcess.kill();
          } catch (_) {/* No Op */}
          reject(new Error('Process execution timed out'));
        }, options.timeout);
      }
    });
  });

  return function exec(_x3) {
    return ref.apply(this, arguments);
  };
}();

var _child_process = require('child_process');

var _extify = require('extify');

var _extify2 = _interopRequireDefault(_extify);

var _helpers = require('./helpers');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { return step("next", value); }, function (err) { return step("throw", err); }); } } return step("next"); }); }; }

function execNode(filePath) {
  var parameters = arguments.length <= 1 || arguments[1] === undefined ? [] : arguments[1];
  var options = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

  (0, _helpers.validate)(filePath, parameters, options);
  return exec(process.execPath, [filePath].concat(parameters), options);
}

module.exports = { exec: exec, execNode: execNode };