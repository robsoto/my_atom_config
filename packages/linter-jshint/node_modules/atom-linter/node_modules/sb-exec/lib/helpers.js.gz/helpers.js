'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getSpawnOptions = exports.assign = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; };

var getSpawnOptions = exports.getSpawnOptions = function () {
  var ref = _asyncToGenerator(function* (options) {
    var spawnOptions = assign({}, options, {
      env: assign((yield (0, _consistentEnv.async)()), options.env)
    });
    var local = options.local;
    if (local) {
      var npmPath = yield _sbNpmPath2.default.async(local.directory);
      for (var key in spawnOptions.env) {
        if (spawnOptions.env.hasOwnProperty(key) && key.toUpperCase() === 'PATH') {
          var value = spawnOptions.env[key];
          spawnOptions.env[key] = local.prepend ? npmPath + PATH_SEPARATOR + value : value + PATH_SEPARATOR + npmPath;
          break;
        }
      }
    }
    spawnOptions.timeout = null;
    if (spawnOptions.env.OS) {
      spawnOptions.env.OS = undefined;
    }
    if (process.versions.electron) {
      spawnOptions.env.ELECTRON_RUN_AS_NODE = '1';
      spawnOptions.env.ATOM_SHELL_INTERNAL_RUN_AS_NODE = '1';
      spawnOptions.env.ELECTRON_NO_ATTACH_CONSOLE = '1';
    }
    return spawnOptions;
  });

  return function getSpawnOptions(_x) {
    return ref.apply(this, arguments);
  };
}();

exports.validate = validate;
exports.mergeAllPaths = mergeAllPaths;
exports.mergeAllPathExts = mergeAllPathExts;

var _assert = require('assert');

var _assert2 = _interopRequireDefault(_assert);

var _consistentEnv = require('consistent-env');

var _sbNpmPath = require('sb-npm-path');

var _sbNpmPath2 = _interopRequireDefault(_sbNpmPath);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { return step("next", value); }, function (err) { return step("throw", err); }); } } return step("next"); }); }; }

var PATH_SEPARATOR = process.platform === 'win32' ? ';' : ':';
var assign = exports.assign = Object.assign || function (target, source) {
  for (var key in source) {
    if (source.hasOwnProperty(key)) {
      target[key] = source[key];
    }
  }
  return target;
};

function validate(filePath, parameters, options) {
  (0, _assert2.default)(typeof filePath === 'string' && filePath, 'filePath must be a string');
  (0, _assert2.default)(Array.isArray(parameters), 'parameters must be an array');
  (0, _assert2.default)((typeof options === 'undefined' ? 'undefined' : _typeof(options)) === 'object' && options, 'options must be an object');
  if (options.stream) {
    var stream = options.stream;
    (0, _assert2.default)(stream === 'both' || stream === 'stdout' || stream === 'stderr', 'options.stream should be stdout|stderr|both');
  } else options.stream = 'stdout';
  if (options.timeout) {
    (0, _assert2.default)(typeof options.timeout === 'number', 'options.timeout must be a number');
  } else options.timeout = Infinity;
  if (options.env) {
    (0, _assert2.default)(_typeof(options.env) === 'object', 'options.env must be an object');
  } else options.env = {};
  if (options.stdin) {
    (0, _assert2.default)(typeof options.stdin === 'string', 'options.stdin must be an object');
  } else options.stdin = null;
  if (typeof options.throwOnStdErr !== 'undefined') {
    (0, _assert2.default)(typeof options.throwOnStdErr === 'boolean', 'options.throwOnStdErr must be a boolean');
  } else options.throwOnStdErr = true;
  if (typeof options.local !== 'undefined') {
    (0, _assert2.default)(_typeof(options.local) === 'object', 'options.local must be an object');
    (0, _assert2.default)(typeof options.local.directory === 'string', 'options.local.directory must be a string');
  }
}

function mergeAllPaths(env) {
  var toReturn = [];
  for (var key in env) {
    if (env.hasOwnProperty(key) && key.toUpperCase() === 'PATH') {
      toReturn.push(env[key]);
    }
  }
  return toReturn.join(';');
}

function mergeAllPathExts(env) {
  var toReturn = [];
  for (var key in env) {
    if (env.hasOwnProperty(key) && key.toUpperCase() === 'PATHEXT') {
      toReturn.push(env[key]);
    }
  }
  return toReturn.join(';');
}