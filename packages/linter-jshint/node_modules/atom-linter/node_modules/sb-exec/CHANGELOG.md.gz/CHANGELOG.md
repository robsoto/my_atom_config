## 1.0.5

- Add fix for EXTPATH on windows

## 1.0.4

- Fix for Atom 1.7.0+ by setting env vars properly

## 1.0.3

- Fix a typo in Electron run as node var

## 1.0.2

- Add `local` option

## 1.0.1

- Make it work with `stdio: inherit`

## 1.0.0

- Initial release
