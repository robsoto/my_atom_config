'use strict';

var extify = function () {
  var ref = _asyncToGenerator(function* (path) {
    var envPath = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
    var envExtPath = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];

    var PATH = (envPath || process.env.PATH || '').split(_path2.default.delimiter);
    var EXTPATH = (envExtPath || (0, _helpers.getExtPath)()).split(';');

    EXTPATH.push('');

    if (_path2.default.isAbsolute(path)) {
      for (var i = 0, length = EXTPATH.length; i < length; ++i) {
        var entry = EXTPATH[i];
        var entryPath = path + entry;
        if (yield (0, _helpers.exists)(entryPath)) {
          return entryPath;
        }
      }
      return path;
    }
    for (var _i2 = 0, _length2 = PATH.length; _i2 < _length2; _i2++) {
      var chunk = PATH[_i2];
      if (!chunk.length) {
        continue;
      }

      for (var _i = 0, _length = EXTPATH.length; _i < _length; _i++) {
        var _entry = EXTPATH[_i];
        var _entryPath = _path2.default.join(PATH[_i2], path + _entry);
        if (yield (0, _helpers.exists)(_entryPath)) {
          return _entryPath;
        }
      }
    }
    return path;
  });

  return function extify(_x3) {
    return ref.apply(this, arguments);
  };
}();

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _helpers = require('./helpers');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { return step("next", value); }, function (err) { return step("throw", err); }); } } return step("next"); }); }; }

function extifySync(path) {
  var envPath = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
  var envExtPath = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];

  var PATH = (envPath || process.env.PATH || '').split(_path2.default.delimiter);
  var EXTPATH = (envExtPath || (0, _helpers.getExtPath)()).split(';');

  EXTPATH.push('');

  if (_path2.default.isAbsolute(path)) {
    for (var i = 0, length = EXTPATH.length; i < length; ++i) {
      var entry = EXTPATH[i];
      var entryPath = path + entry;
      if ((0, _helpers.existsSync)(entryPath)) {
        return entryPath;
      }
    }
    return path;
  }
  for (var _i3 = 0, _length3 = PATH.length; _i3 < _length3; _i3++) {
    var chunk = PATH[_i3];
    if (!chunk.length) {
      continue;
    }

    for (var _i = 0, _length = EXTPATH.length; _i < _length; _i++) {
      var _entry2 = EXTPATH[_i];
      var _entryPath2 = _path2.default.join(PATH[_i3], path + _entry2);
      if ((0, _helpers.existsSync)(_entryPath2)) {
        return _entryPath2;
      }
    }
  }
  return path;
}

module.exports = extify;
module.exports.sync = extifySync;