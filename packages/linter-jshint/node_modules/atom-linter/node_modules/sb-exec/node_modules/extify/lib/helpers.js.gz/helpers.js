'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.exists = exists;
exports.existsSync = existsSync;
exports.getExtPath = getExtPath;

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function exists(filePath) {
  return new Promise(function (resolve) {
    _fs2.default.stat(filePath, function (error) {
      resolve(error === null);
    });
  });
}

function existsSync(filePath) {
  try {
    _fs2.default.statSync(filePath);
    return true;
  } catch (_) {
    return false;
  }
}

function getExtPath() {
  for (var key in process.env) {
    if (process.env.hasOwnProperty(key) && key.toUpperCase() === 'EXTPATH') {
      return process.env[key] || '';
    }
  }
  return '';
}