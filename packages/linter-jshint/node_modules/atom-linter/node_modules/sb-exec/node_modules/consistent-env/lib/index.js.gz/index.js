'use strict';

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _helpers = require('./helpers');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function () {
  if (process.platform === 'win32') {
    return (0, _helpers.assign)({}, process.env);
  }
  if (global[_helpers.CACHE_KEY]) {
    return (0, _helpers.assign)({}, global[_helpers.CACHE_KEY]);
  }
  const shellName = _path2.default.basename(process.env.SHELL);
  if (_helpers.KNOWN_SHELLS.indexOf(shellName) === -1) {
    return (0, _helpers.assign)({}, process.env);
  }
  try {
    const environment = (0, _helpers.applySugar)((0, _helpers.parse)((0, _helpers.identifyEnvironment)()));
    global[_helpers.CACHE_KEY] = environment;
    return environment;
  } catch (error) {
    console.error('[consistent-env] Unable to determine environment', error);
    return (0, _helpers.assign)({}, process.env);
  }
};

module.exports.async = function () {
  return new Promise(function (resolve) {
    if (process.platform === 'win32') {
      resolve((0, _helpers.assign)({}, process.env));
    } else if (global[_helpers.CACHE_KEY]) {
      resolve((0, _helpers.assign)({}, global[_helpers.CACHE_KEY]));
    } else {
      const shellName = _path2.default.basename(process.env.SHELL);
      if (_helpers.KNOWN_SHELLS.indexOf(shellName) === -1) {
        resolve((0, _helpers.assign)({}, process.env));
      } else {
        resolve((0, _helpers.identifyEnvironmentAsync)().then(_helpers.parse).then(_helpers.applySugar).then(function (environment) {
          global[_helpers.CACHE_KEY] = environment;
          return environment;
        }));
      }
    }
  }).catch(function (error) {
    console.error('[consistent-env] Unable to determine environment', error);
    return (0, _helpers.assign)({}, process.env);
  });
};