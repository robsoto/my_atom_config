'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.assign = exports.CACHE_KEY = exports.KNOWN_SHELLS = undefined;
exports.identifyEnvironment = identifyEnvironment;
exports.identifyEnvironmentAsync = identifyEnvironmentAsync;
exports.parse = parse;
exports.applySugar = applySugar;
exports.getCommand = getCommand;

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _child_process = require('child_process');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const DEFAULT_PATHS = ['/bin', '/sbin', '/usr/bin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin'];
const KNOWN_SHELLS = exports.KNOWN_SHELLS = ['zsh', 'bash', 'fish'];
const CACHE_KEY = exports.CACHE_KEY = '__STEELBRAIN_CONSISTENT_ENV_V1';
const assign = exports.assign = Object.assign || function (target, source) {
  for (const key in source) {
    if (source.hasOwnProperty(key)) {
      target[key] = source[key];
    }
  }
  return target;
};

function identifyEnvironment() {
  let environment;

  var _getCommand = getCommand();

  const command = _getCommand.command;
  const parameters = _getCommand.parameters;
  const options = _getCommand.options;

  environment = (0, _child_process.spawnSync)(command, parameters, options).stdout.toString().trim().split('\n');
  return environment;
}

function identifyEnvironmentAsync() {
  return new Promise(function (resolve, reject) {
    var _getCommand2 = getCommand();

    const command = _getCommand2.command;
    const parameters = _getCommand2.parameters;
    const options = _getCommand2.options;

    const childProcess = (0, _child_process.spawn)(command, parameters, options);
    const stdout = [];
    const timer = setTimeout(function () {
      childProcess.kill();
      reject(new Error('Process execution timed out'));
    }, 2000);
    childProcess.stdout.on('data', function (chunk) {
      stdout.push(chunk);
    });
    childProcess.on('close', function () {
      clearTimeout(timer);
      resolve(stdout.join('').trim().split('\n'));
    });
    childProcess.on('error', function (error) {
      reject(error);
    });
  }).catch(function () {
    throw new Error('Unable to determine environment');
  });
}

function parse(rawEnvironment) {
  const environment = {};
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = rawEnvironment[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      const chunk = _step.value;

      const index = chunk.indexOf('=');
      if (index !== -1) {
        const key = chunk.slice(0, index).trim();
        const value = chunk.slice(index + 1).trim();
        environment[key] = value;
      }
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return environment;
}

function applySugar(environment) {
  let path = process.env.PATH ? process.env.PATH.split(':') : [];
  if (environment.PATH) {
    var _iteratorNormalCompletion2 = true;
    var _didIteratorError2 = false;
    var _iteratorError2 = undefined;

    try {
      for (var _iterator2 = environment.PATH.split(':')[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
        const chunk = _step2.value;

        if (chunk && path.indexOf(chunk) === -1) {
          path.push(chunk);
        }
      }
    } catch (err) {
      _didIteratorError2 = true;
      _iteratorError2 = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion2 && _iterator2.return) {
          _iterator2.return();
        }
      } finally {
        if (_didIteratorError2) {
          throw _iteratorError2;
        }
      }
    }
  }
  var _iteratorNormalCompletion3 = true;
  var _didIteratorError3 = false;
  var _iteratorError3 = undefined;

  try {
    for (var _iterator3 = DEFAULT_PATHS[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
      const entry = _step3.value;

      if (path.indexOf(entry) === -1) {
        path = [entry].concat(path);
      }
    }
  } catch (err) {
    _didIteratorError3 = true;
    _iteratorError3 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion3 && _iterator3.return) {
        _iterator3.return();
      }
    } finally {
      if (_didIteratorError3) {
        throw _iteratorError3;
      }
    }
  }

  if (!environment.USER) {
    if (process.env.USER) {
      environment.USER = process.env.USER;
    } else if (environment.HOME) {
      environment.USER = _path2.default.basename(environment.HOME);
    }
  }

  environment.PATH = path.join(':');
  environment.PWD = environment.OLDPWD = process.cwd();
  return environment;
}

function getCommand() {
  let command = process.env.SHELL;
  let parameters;
  let options = { timeout: 3000, encoding: 'utf8' };

  const shell = _path2.default.basename(process.env.SHELL);
  if (shell === 'bash') {
    parameters = ['-c', 'source ~/.bashrc;env;exit'];
  } else if (shell === 'zsh') {
    parameters = ['-c', 'source ~/.zshrc;env;exit'];
  } else if (shell === 'fish') {
    parameters = ['-c', 'source ~/.config/fish/config.fish;env;exit'];
  }

  return { command: command, parameters: parameters, options: options };
}