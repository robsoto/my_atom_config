## v1.1.2

- Do not throw errors if there were problems detecting environment, instead log them to console

## v1.1.1

- Add support for `fish` shell

## v1.1.0

- Add more defaults PATH locations
- Improved handling of unknown shell types

## v1.0.1

- Fix a bug in where this module would hang forever in Atom Editor on Linux Platform (OSX stays unaffected)

## v1.0.0

- Initial release
