'use strict';

var CACHE_DELETED = Symbol('cache deleted');

function memoize(callback) {
  var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

  function memoized() {
    for (var _len = arguments.length, parameters = Array(_len), _key = 0; _key < _len; _key++) {
      parameters[_key] = arguments[_key];
    }

    var cacheKey = JSON.stringify(parameters);
    var parametersLength = parameters.length;

    if (cacheKey in memoized.__sb_cache && memoized.__sb_cache[cacheKey] !== CACHE_DELETED) {
      var _value = memoized.__sb_cache[cacheKey];
      if (options.async && !(_value && _value.constructor.name === 'Promise')) {
        return Promise.resolve(_value);
      }
      return _value;
    }

    var value = void 0;
    if (parametersLength === 1) {
      value = callback.call(this, parameters[0]);
    } else if (parametersLength === 2) {
      value = callback.call(this, parameters[0], parameters[1]);
    } else if (parametersLength === 3) {
      value = callback.call(this, parameters[0], parameters[1], parameters[2]);
    } else if (parametersLength === 4) {
      value = callback.call(this, parameters[0], parameters[1], parameters[2], parameters[3]);
    } else {
      value = callback.apply(this, parameters);
    }

    memoized.__sb_cache[cacheKey] = value;
    if (options.async) {
      if (!value || value.constructor.name !== 'Promise') {
        throw new Error('Memoization Error, Async function returned non-promise value');
      }
      return value.then(function (realValue) {
        memoized.__sb_cache[cacheKey] = realValue;
        return realValue;
      }, function (error) {
        memoized.__sb_cache[cacheKey] = CACHE_DELETED;
        throw error;
      });
    }
    return value;
  }
  memoized.__sb_cache = {};

  return memoized;
}

module.exports = memoize;