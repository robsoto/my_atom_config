## 1.0.2

- Fix a case where rejected promises would be cached

## 1.0.1

- Allow sharing caches between memoized functions, you can do so by doing `a.__sb_cache = b.__sb_cache`

## 1.0.0

- Initial release
