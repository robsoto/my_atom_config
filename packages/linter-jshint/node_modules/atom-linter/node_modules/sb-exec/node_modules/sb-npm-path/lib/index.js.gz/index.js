'use strict';

var getPATHAsync = function () {
  var ref = _asyncToGenerator(function* () {
    var currentDirectory = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

    if (!currentDirectory) {
      currentDirectory = process.cwd();
    }
    var entries = yield (0, _helpers.findAsync)(currentDirectory, [_path2.default.join('node_modules', '.bin')]);
    return entries.join(SEPARATOR);
  });

  return function getPATHAsync() {
    return ref.apply(this, arguments);
  };
}();

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _helpers = require('./helpers');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { return step("next", value); }, function (err) { return step("throw", err); }); } } return step("next"); }); }; }

var SEPARATOR = process.platform === 'win32' ? ';' : ':';

function getPATH() {
  var currentDirectory = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

  if (!currentDirectory) {
    currentDirectory = process.cwd();
  }
  var entries = (0, _helpers.find)(currentDirectory, [_path2.default.join('node_modules', '.bin')]);
  return entries.join(SEPARATOR);
}

module.exports = getPATH;
module.exports.async = getPATHAsync;
module.exports.clearCache = function () {
  _helpers.find.__sb_cache = {};
  _helpers.findAsync.__sb_cache = {};
};