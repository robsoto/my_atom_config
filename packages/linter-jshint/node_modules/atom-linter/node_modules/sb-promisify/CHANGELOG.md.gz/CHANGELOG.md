#### 1.3.0

- Add `promisifyAll` method

#### 1.2.0

- Add `throwError` parameter

#### 1.1.1

- Support older runtimes by using only Array.from when available and falling back to Array.prototype.slice

#### 1.1.0

- Use commonjs exports intead of ES exports

#### 1.0.0

- Initial implementation
