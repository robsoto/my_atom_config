'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.install = undefined;

let install = exports.install = (function () {
  var ref = _asyncToGenerator(function* () {
    let name = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

    if (!name) {
      name = require('atom-package-path').guessFromCallIndex(5);
    }
    if (!name) {
      console.error(`[Package-Deps] Unable to get package name for file: ${ filePath }`);
      return;
    }

    const dependencies = (0, _helpers.getDependencies)(name);
    if (dependencies.length) {
      yield atom.packages.activatePackage('notifications');
      yield (0, _helpers.installDependencies)(name, dependencies);
    }
  });

  return function install(_x) {
    return ref.apply(this, arguments);
  };
})();

var _helpers = require('./helpers');

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, "next"); var callThrow = step.bind(null, "throw"); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

if (typeof window.__steelbrain_package_deps === 'undefined') {
  window.__steelbrain_package_deps = new Set();
}
