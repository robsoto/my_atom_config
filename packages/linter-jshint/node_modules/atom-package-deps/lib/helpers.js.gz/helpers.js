'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.installDependencies = undefined;

let installDependencies = exports.installDependencies = (function () {
  var ref = _asyncToGenerator(function* (name, packages) {
    const view = new _view.View(name, packages);
    const installedPackages = [];
    try {
      yield spawnAPM(packages, function (name, status) {
        view.advance();
        if (status) {
          installedPackages.push(name);
        }
      });
      view.markFinished();
    } catch (error) {
      view.dismiss();
      atom.notifications.addError(`Error installing ${ name } dependencies`, {
        detail: error.stack,
        dismissable: true
      });
    } finally {
      yield Promise.all(installedPackages.map(function (name) {
        return atom.packages.activatePackage(name);
      }));
    }
  });

  return function installDependencies(_x, _x2) {
    return ref.apply(this, arguments);
  };
})();

exports.spawnAPM = spawnAPM;
exports.getDependencies = getDependencies;

var _atom = require('atom');

var _view = require('./view');

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, "next"); var callThrow = step.bind(null, "throw"); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

const extractionRegex = /Installing (.*?) to .* (.*)/;

function spawnAPM(dependencies, progressCallback) {
  return new Promise(function (resolve, reject) {
    const errors = [];
    new _atom.BufferedProcess({
      command: atom.packages.getApmPath(),
      args: ['install'].concat(dependencies).concat(['--production', '--color', 'false']),
      options: {},
      stdout: function (contents) {
        const matches = extractionRegex.exec(contents);
        if (matches[2] === '✓' || matches[2] === 'done') {
          progressCallback(matches[1], true);
        } else {
          progressCallback(matches[1], false);
          errors.push(matches[1]);
        }
      },
      stderr: function (contents) {
        const lastIndex = errors.length - 1;
        errors[lastIndex] += ': ' + contents;
      },
      exit: function () {
        if (errors.length) {
          const error = new Error('Error installing dependencies');
          error.stack = errors.join('\n');
          reject(error);
        } else resolve();
      }
    });
  });
}

function getDependencies(name) {
  const toReturn = [];
  const packageModule = atom.packages.getLoadedPackage(name);
  const packageDependencies = packageModule && packageModule.metadata['package-deps'];

  if (packageDependencies) {
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = packageDependencies[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        const name = _step.value;

        if (!__steelbrain_package_deps.has(name)) {
          __steelbrain_package_deps.add(name);
          if (!atom.packages.resolvePackagePath(name)) {
            toReturn.push(name);
          }
        }
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }
  } else {
    console.error(`[Package-Deps] Unable to get package info for ${ name }`);
  }

  return toReturn;
}
