#### 1.1.0

- Add `guessFromCallIndex` function

#### 1.0.2

- Minor package internl problem resolved

#### 1.0.1

- Add specs to ensure stability
- Add support for non-common paths

#### 1.0.0

- Initial version
