### 1.1.2

 - Make capture work again on filepaths with spaces (bug introduced in v1.1.1)

### 1.1.1

 - Improve regexp capture speed

### 1.1.0

 - `fromStack` method implemented

### 1.0.1

 - `capture` method implemented
