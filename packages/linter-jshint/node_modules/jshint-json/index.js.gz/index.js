module.exports = require('path').join(__dirname, 'json.js');
