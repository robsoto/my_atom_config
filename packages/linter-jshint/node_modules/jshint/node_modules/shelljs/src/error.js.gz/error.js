var common = require('./common');

//@
//@ ### error()
//@ Tests if error occurred in the last command. Returns `null` if no error occurred,
//@ otherwise returns string explaining the error
function error() {
  return common.state.error;
};
module.exports = error;
