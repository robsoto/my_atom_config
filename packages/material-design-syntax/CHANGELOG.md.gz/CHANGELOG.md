## 1.6.1
- updated getStyleSheetsPath

## 1.6
- updated editor calls

## 1.5
- updated todo-language support for "hack"

## 1.4
- updated readme stuffs
- added a screenshot

## 1.3
- made wrap-guide lighter

## 1.2
- made todo-language pink!

## 1.1
- removed pink in favor of white

## 1.0
- First Release
