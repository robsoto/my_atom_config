# material-design-syntax theme

A syntax theme based off the beautiful colors of Android's Material Design color pallete.

I'm constantly tweaking and adjusting this theme every day. Expect it to get better and better!

Recommended to use this syntax-theme with [<b>isotope-ui</b>](https://atom.io/themes/isotope-ui)
(I suggest setting a custom background color of #121212 for maximum dankitude)

![A screenshot of my theme](http://i.imgur.com/0oZCR2R.png)
