# underscore-plus [![Build Status](https://travis-ci.org/atom/underscore-plus.svg?branch=master)](https://travis-ci.org/atom/underscore-plus)

Takes the great [underscore](http://underscorejs.org/) library and adds a few
more things.

## Using

```sh
npm install underscore-plus
```

```coffeescript
_ = require 'underscore-plus' # Has all underscore methods and more
```
