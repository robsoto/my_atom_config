'use babel'

export default class BabelDummy {
  createdCallback () {
    this.name = 'dummy'
  }
}
