(function() {
  var Disposable, DisposableEvents, Mixin, _ref,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Mixin = require('mixto');

  Disposable = require('event-kit').Disposable;

  module.exports = DisposableEvents = (function(_super) {
    __extends(DisposableEvents, _super);

    function DisposableEvents() {
      _ref = DisposableEvents.__super__.constructor.apply(this, arguments);
      return _ref;
    }

    DisposableEvents.prototype.addDisposableEventListener = function(object, event, listener) {
      object.addEventListener(event, listener);
      return new Disposable(function() {
        return object.removeEventListener(event, listener);
      });
    };

    return DisposableEvents;

  })(Mixin);

}).call(this);
