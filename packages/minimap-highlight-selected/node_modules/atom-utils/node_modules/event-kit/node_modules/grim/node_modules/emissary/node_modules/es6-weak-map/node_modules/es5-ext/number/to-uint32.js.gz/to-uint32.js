'use strict';

module.exports = function (value) { return value >>> 0; };
