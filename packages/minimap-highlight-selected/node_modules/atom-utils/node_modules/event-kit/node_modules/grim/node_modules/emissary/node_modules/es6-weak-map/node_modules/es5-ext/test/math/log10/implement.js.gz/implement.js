'use strict';

var isImplemented = require('../../../math/log10/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
