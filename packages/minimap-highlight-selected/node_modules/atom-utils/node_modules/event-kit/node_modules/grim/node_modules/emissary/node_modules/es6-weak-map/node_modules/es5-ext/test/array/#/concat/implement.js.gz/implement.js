'use strict';

var isImplemented = require('../../../../array/#/concat/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
