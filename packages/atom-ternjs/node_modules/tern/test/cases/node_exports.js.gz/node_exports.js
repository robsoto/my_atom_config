// plugin=node

exports.a = 10;

exports.b = function() {};

//exports: {a: number, b: fn()}
