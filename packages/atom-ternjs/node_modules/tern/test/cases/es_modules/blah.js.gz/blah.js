export var a = 10
export let b = "ten", c = true
export function d() { return 10 }
