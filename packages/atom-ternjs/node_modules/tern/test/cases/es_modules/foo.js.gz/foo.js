export default 22

export function hello() { return true }

export var heythere = 100
