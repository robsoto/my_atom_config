// plugin=webpack

require("foo") //:: {browser: bool}

require("foo/index") //:: {index: bool}
