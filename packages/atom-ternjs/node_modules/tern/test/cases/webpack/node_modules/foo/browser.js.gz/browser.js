module.exports = {browser: true}
