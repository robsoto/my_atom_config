// plugin=complete_strings
// blank-comments=true

if (x == "foobar") {
  apparently(x == "f
//<+ "foobar"
}
