exports.abc = 1;
exports.def = require("./other.js");
