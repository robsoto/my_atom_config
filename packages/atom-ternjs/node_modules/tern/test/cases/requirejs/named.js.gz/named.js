define("myname", ["exports"], function(exports) {
  exports.foo = {a: 10};
});
