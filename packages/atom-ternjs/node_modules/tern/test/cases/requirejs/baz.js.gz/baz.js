define("foo", function(foo) {
  return {bazProp: new Date, bazFooProp: foo.aString};
});
