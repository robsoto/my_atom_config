define(function(require, exports) {
  exports.hello = require("foo").aString;
  exports.func = require("func");
});
