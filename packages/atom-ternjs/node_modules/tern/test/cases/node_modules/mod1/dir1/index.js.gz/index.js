exports.foo = {a: 10};
