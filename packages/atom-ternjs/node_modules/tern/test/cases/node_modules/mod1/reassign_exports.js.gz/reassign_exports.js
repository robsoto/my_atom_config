module.exports = function() {};
module.exports.funcPropExport = 7;
