module.exports = {
  // doc for f1
  f1: function() { return 7; }
};

// doc for f2
module.exports.f2 = function() { return 7; };
