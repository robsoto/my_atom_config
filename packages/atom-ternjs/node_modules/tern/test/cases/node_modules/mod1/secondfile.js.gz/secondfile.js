exports.secondExport = {u: 10, v: 20};
