exports.mainExport = {x: 10, y: 20};

exports.fromSubdep = require("subdep1").subdepFunc;
