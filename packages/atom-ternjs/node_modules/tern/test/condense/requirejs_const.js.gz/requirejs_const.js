define({a: "a"});
