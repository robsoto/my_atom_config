function a(){}
var b = a;
