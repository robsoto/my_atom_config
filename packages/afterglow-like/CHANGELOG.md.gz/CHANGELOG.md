# Changelog

### 0.2.1
*2015-5-19*
- Fix wrap guide dashyness

### 0.2.0
*2015-3-13*
- Make invisibles transparent

### 0.1.0
*2015-3-11*
- Convert Sublime Syntax
