# Afterglow Like
###### An Atom Syntax Theme - [Atom.io](https://atom.io/packages/afterglow-like) : [Github](https://github.com/dsandstrom/atom-afterglow-like-syntax)

A minimal dark syntax theme converted from [Afterglow](https://github.com/YabataDesign/afterglow-theme) (Sublime Text). The syntax color scheme is mostly derived from [idlefingers](http://idlefingers.co.uk/).

![Afterglow Like](https://cloud.githubusercontent.com/assets/1400414/6611657/41159822-c82c-11e4-9f9c-38c6d46d3a36.png)

### Notes
A UI Theme is planned, but for now I use [Isotope UI](https://github.com/braver/isotope-ui) with a custom background color of #252525.
