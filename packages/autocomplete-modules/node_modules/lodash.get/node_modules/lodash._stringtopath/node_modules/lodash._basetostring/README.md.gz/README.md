# lodash._basetostring v4.12.0

The internal [lodash](https://lodash.com/) function `baseToString` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash._basetostring
```

In Node.js:
```js
var baseToString = require('lodash._basetostring');
```

See the [package source](https://github.com/lodash/lodash/blob/4.12.0-npm-packages/lodash._basetostring) for more details.
