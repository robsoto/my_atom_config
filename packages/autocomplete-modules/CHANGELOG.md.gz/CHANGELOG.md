## v0.3.0
 * Added packages internal files lookup

## v0.2.2
* Remove local file extensions for js/coffee

## v0.2.0
* Added local files lookup

## v0.1.0 First Release
* Added internal modules lookup
* Added node_modules lookup
