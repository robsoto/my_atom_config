var o = [,,,,]

require('./foo')
