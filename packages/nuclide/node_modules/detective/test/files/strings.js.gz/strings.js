var a = require('a');
var b = require('b');
var c = require('c');
var abc = a.b(c);

var EventEmitter = require('events').EventEmitter;

var x = require('doom')(5,6,7);
x(8,9);
c.require('notthis');
var y = require('y') * 100;

var EventEmitter2 = require('events2').EventEmitter();