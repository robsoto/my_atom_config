"use strict";

let Observable, trackOperationTiming;

module.exports = _client => {
  const remoteModule = {};

  remoteModule.getServerVersion = function () {
    return _client.marshalArguments(Array.from(arguments), []).then(args => {
      return _client.callRemoteFunction("InfoService/getServerVersion", "promise", args);
    }).then(value => {
      return _client.unmarshal(value, {
        location: {
          type: "source",
          fileName: "InfoService.js",
          line: 18
        },
        kind: "string"
      });
    });
  };

  remoteModule.closeConnection = function (arg0) {
    return _client.marshalArguments(Array.from(arguments), [{
      name: "shutdownServer",
      type: {
        location: {
          type: "source",
          fileName: "InfoService.js",
          line: 25
        },
        kind: "boolean"
      }
    }]).then(args => {
      return _client.callRemoteFunction("InfoService/closeConnection", "promise", args);
    }).then(value => {
      return _client.unmarshal(value, {
        location: {
          type: "source",
          fileName: "InfoService.js",
          line: 25
        },
        kind: "void"
      });
    });
  };

  return remoteModule;
};

Object.defineProperty(module.exports, "inject", {
  value: function () {
    Observable = arguments[0];
    trackOperationTiming = arguments[1];
  }
});
Object.defineProperty(module.exports, "defs", {
  value: new Map([["Object", {
    kind: "alias",
    name: "Object",
    location: {
      type: "builtin"
    }
  }], ["Date", {
    kind: "alias",
    name: "Date",
    location: {
      type: "builtin"
    }
  }], ["RegExp", {
    kind: "alias",
    name: "RegExp",
    location: {
      type: "builtin"
    }
  }], ["Buffer", {
    kind: "alias",
    name: "Buffer",
    location: {
      type: "builtin"
    }
  }], ["fs.Stats", {
    kind: "alias",
    name: "fs.Stats",
    location: {
      type: "builtin"
    }
  }], ["NuclideUri", {
    kind: "alias",
    name: "NuclideUri",
    location: {
      type: "builtin"
    }
  }], ["getServerVersion", {
    kind: "function",
    name: "getServerVersion",
    location: {
      type: "source",
      fileName: "InfoService.js",
      line: 18
    },
    type: {
      location: {
        type: "source",
        fileName: "InfoService.js",
        line: 18
      },
      kind: "function",
      argumentTypes: [],
      returnType: {
        location: {
          type: "source",
          fileName: "InfoService.js",
          line: 18
        },
        kind: "promise",
        type: {
          location: {
            type: "source",
            fileName: "InfoService.js",
            line: 18
          },
          kind: "string"
        }
      }
    }
  }], ["closeConnection", {
    kind: "function",
    name: "closeConnection",
    location: {
      type: "source",
      fileName: "InfoService.js",
      line: 25
    },
    type: {
      location: {
        type: "source",
        fileName: "InfoService.js",
        line: 25
      },
      kind: "function",
      argumentTypes: [{
        name: "shutdownServer",
        type: {
          location: {
            type: "source",
            fileName: "InfoService.js",
            line: 25
          },
          kind: "boolean"
        }
      }],
      returnType: {
        location: {
          type: "source",
          fileName: "InfoService.js",
          line: 25
        },
        kind: "promise",
        type: {
          location: {
            type: "source",
            fileName: "InfoService.js",
            line: 25
          },
          kind: "void"
        }
      }
    }
  }]])
});