#!/bin/bash
node echo.js $@
