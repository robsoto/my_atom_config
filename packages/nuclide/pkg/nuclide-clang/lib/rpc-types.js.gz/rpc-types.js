/*
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the LICENSE file in
 * the root directory of this source tree.
 *
 * @flow
 */


import type {NuclideUri} from '../../nuclide-remote-uri';

// NOTE that the definitions in this file are shared between
// the ClangService and ClangProcessService.


// TODO: Support enums in rpc3 framework.
// export type ClangCursorType = $Enum<typeof ClangCursorToDeclarationTypes>;
export type ClangCursorType = string;

export type ClangCursorExtent = {
  start: {line: number; column: number};
  end: {line: number; column: number};
};

export type ClangLocation = {
  column: number;
  file: ?NuclideUri;
  line: number;
};

export type ClangSourceRange = {
  file: NuclideUri;
  start: {line: number; column: number};
  end: {line: number; column: number};
};

export type ClangCompileResult = {
  diagnostics: Array<{
    spelling: string;
    severity: number;
    location: ClangLocation;
    ranges: ?Array<ClangSourceRange>;
    fixits?: Array<{
      range: ClangSourceRange;
      value: string;
    }>;
    // Diagnostics often have children. This happens for errors like bad function args.
    // Clang emits one diagnostic saying "matching invocation of function f not found"
    // with one or more child diagnostics listing the reasons.
    // (e.g. mismatched types, wrong number of arguments)
    //
    // These technically contain all the fields listed above, but we don't really have a good
    // use for them so they are omitted.
    // In theory, these can also have child diagnostics! Unclear if this ever occurs in practice.
    children?: Array<{
      spelling: string;
      location: ClangLocation;
      ranges: Array<ClangSourceRange>;
    }>;
  }>;
  // If defaultFlags was provided and used, this will be set to true.
  // `diagnostics` is likely to be inaccurate if this was the case.
  accurateFlags?: boolean;
};

export type ClangCompletion = {
  chunks: Array<{
    spelling: string;
    isPlaceHolder: boolean;
    kind?: string;
  }>;
  result_type: string;
  spelling: string;
  cursor_kind: string;
  brief_comment: ?string;
};

export type ClangDeclaration = {
  file: NuclideUri;
  line: number;
  column: number;
  spelling: ?string;
  type: ?string;
  extent: ClangCursorExtent;
};

export type ClangCursor = {
  name: string;
  type: ClangCursorType;
  cursor_usr: ?string;
  file: ?NuclideUri;
};

export type ClangOutlineTree = {
  name: string;
  extent: ClangCursorExtent;
  cursor_kind: ClangCursorType;
  // Will be non-null for variables/typedefs only.
  cursor_type?: string;
  // Will be non-null for functions and methods only.
  // Contains a list of the names of parameters.
  params?: Array<string>;
  // List of template parameters (functions/methods only).
  tparams?: Array<string>;
  // Will be non-null for class-like containers only.
  children?: Array<ClangOutlineTree>;
};
