Object.defineProperty(exports, '__esModule', {
  value: true
});

/*
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the LICENSE file in
 * the root directory of this source tree.
 */

var GADGET_CREATED = 'gadget-created';
exports.GADGET_CREATED = GADGET_CREATED;
var GADGET_DESERIALIZED = 'gadget-deserialized';
exports.GADGET_DESERIALIZED = GADGET_DESERIALIZED;