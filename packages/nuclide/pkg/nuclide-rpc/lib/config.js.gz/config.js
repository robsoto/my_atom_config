Object.defineProperty(exports, '__esModule', {
  value: true
});

/*
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the LICENSE file in
 * the root directory of this source tree.
 */

var SERVICE_FRAMEWORK3_PROTOCOL = 'service_framework3_rpc';
exports.SERVICE_FRAMEWORK3_PROTOCOL = SERVICE_FRAMEWORK3_PROTOCOL;