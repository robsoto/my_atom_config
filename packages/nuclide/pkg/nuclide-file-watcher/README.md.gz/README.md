# Nuclide file-watcher

Watches open files for conflicts between editor filesystem edits, then Atom confirm prompt to reload.

That was ported from Atom's [file-watcher](https://atom.io/packages/file-watcher) package to work across local and remote files.
