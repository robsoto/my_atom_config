# nuclide-notifications

This feature provides native notification support for Nuclide & Atom.
