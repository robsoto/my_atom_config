return module.exports = process.versions.modules > 45;
