// "pre-binding" behaves like "node-pre-gyp"'s "find", but doesn't include
// anything else (e.g. building).
'use strict';
module.exports = require('pre-binding');
