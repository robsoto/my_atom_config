Object.defineProperty(exports, '__esModule', {
  value: true
});

/*
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the LICENSE file in
 * the root directory of this source tree.
 */

// Output from executor.js

// Messages coming from React Native

// Messages from RN are basically forwarded directly to the executor, so the types are pretty much
// identical.

// This shouldn't be present, but apparently can be in some situations?