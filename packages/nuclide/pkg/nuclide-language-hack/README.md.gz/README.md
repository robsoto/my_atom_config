# Hack language support in Atom

Adds syntax highlighting and snippets to Hack files in Atom.

Originally [converted](http://atom.io/docs/latest/converting-a-text-mate-bundle)
from the [PHP TextMate bundle](https://github.com/textmate/php.tmbundle).

Then, forked from: https://github.com/atom/language-php version 0.24.0

[PHPLangPackage]:https://github.com/atom/language-php
[HackLang]:https://github.com/facebook/hhvm
