Unfortunately F5 is taken by another package, so we must use F8 for
`nuclide-debugger:continue-debugging`.
