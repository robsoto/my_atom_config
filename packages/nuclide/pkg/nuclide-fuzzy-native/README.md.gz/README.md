This is a small wrapper around https://github.com/hansonw/fuzzy-native.
Run `scripts/sync.sh` to update.

Includes a fallback fuzzy-search implementation if the native module fails to load.
