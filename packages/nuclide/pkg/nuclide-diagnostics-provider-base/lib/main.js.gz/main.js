Object.defineProperty(exports, '__esModule', {
  value: true
});

/*
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the license found in the LICENSE file in
 * the root directory of this source tree.
 */

var _DiagnosticsProviderBase2;

function _DiagnosticsProviderBase() {
  return _DiagnosticsProviderBase2 = require('./DiagnosticsProviderBase');
}

exports.DiagnosticsProviderBase = (_DiagnosticsProviderBase2 || _DiagnosticsProviderBase()).DiagnosticsProviderBase;