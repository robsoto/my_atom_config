'use strict';

var isImplemented = require('../../../string/raw/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
