'use strict';

var isImplemented = require('../../../object/assign/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
